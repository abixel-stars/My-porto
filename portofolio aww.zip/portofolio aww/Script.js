document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.querySelectorAll('.nav-links li');
    const sections = document.querySelectorAll('.section');
    const sidebar = document.querySelector('.sidebar');
    const main = document.querySelector('main');

    const showSection = (sectionId) => {
        sections.forEach(section => {
            section.classList.remove('active');
        });

        const selectedSection = document.getElementById(sectionId);
        if (selectedSection) {
            selectedSection.classList.add('active');

            selectedSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    };

    const handleNavigation = (e) => {
        navLinks.forEach(navLink => navLink.classList.remove('active'));
        e.currentTarget.classList.add('active');

        const sectionId = e.currentTarget.getAttribute('data-section');
        showSection(sectionId);

        if (window.innerWidth <= 1024) {
            sidebar.classList.remove('mobile-menu-open');
            document.querySelector('.mobile-menu-toggle')?.classList.remove('active');
        }
    };

    navLinks.forEach(link => {
        link.addEventListener('click', handleNavigation);
    });


    const createMobileMenu = () => {
        document.querySelector('.mobile-menu-toggle')?.remove();

        const menuToggle = document.createElement('div');
        menuToggle.classList.add('mobile-menu-toggle');
        menuToggle.innerHTML = `
            <span></span>
            <span></span>
            <span></span>
        `;
        
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('mobile-menu-open');
            menuToggle.classList.toggle('active');
        });

        sidebar.insertBefore(menuToggle, sidebar.firstChild);
    };

    const handleResponsiveness = () => {
        const screenWidth = window.innerWidth;
        
        if (screenWidth <= 1024) {
            createMobileMenu();
            sidebar.classList.add('mobile-menu');
            
            main.style.marginLeft = '0';
            main.style.width = '100%';
            main.style.padding = '0 15px';
        } else {
            // Mode desktop
            document.querySelector('.mobile-menu-toggle')?.remove();
            sidebar.classList.remove('mobile-menu', 'mobile-menu-open');
            
            // Kembalikan layout main
            main.style.marginLeft = '250px';
            main.style.width = 'calc(100% - 250px)';
            main.style.padding = '50px';
        }
    };

    // CTA Button Navigation
    const ctaButtons = document.querySelectorAll('.cta-buttons a, .contact-form a');
    ctaButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const targetSectionId = e.target.getAttribute('href').substring(1);
            
            // Update navigasi
            navLinks.forEach(link => link.classList.remove('active'));
            const correspondingNavLink = document.querySelector(`.nav-links li[data-section="${targetSectionId}"]`);
            if (correspondingNavLink) {
                correspondingNavLink.classList.add('active');
            }
            showSection(targetSectionId);
        });
    });

    handleResponsiveness();
    window.addEventListener('resize', handleResponsiveness);
});

document.addEventListener('DOMContentLoaded', () => {
    const servicesSection = document.createElement('section');
    servicesSection.id = 'services';
    servicesSection.classList.add('section');
    servicesSection.innerHTML = `
        <div class="container">
            <h2 class="section-title">My Services</h2>
            <div class="services-grid">
                <div class="service-card web-dev-card">
                    <div class="service-card-header">
                        <div class="service-icon">
                            <i class="fas fa-code"></i>
                        </div>
                        <h3>Web Development</h3>
                    </div>
                    <div class="service-card-content">
                        <div class="service-price">
                            <span class="price-label">Starting at</span>
                            <span class="price-value">$99</span>
                        </div>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> Responsive Design</li>
                            <li><i class="fas fa-check"></i> Frontend Development</li>
                            <li><i class="fas fa-check"></i> SEO Optimization</li>
                        </ul>
                        <div class="service-card-footer">
                            <a href="#contact" class="btn btn-primary">Get Started</a>
                        </div>
                    </div>
                </div>

                <div class="service-card web-design-card">
                    <div class="service-card-header">
                        <div class="service-icon">
                            <i class="fas fa-palette"></i>
                        </div>
                        <h3>Web Design</h3>
                    </div>
                    <div class="service-card-content">
                        <div class="service-price">
                            <span class="price-label">Starting at</span>
                            <span class="price-value">$79</span>
                        </div>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> UI/UX Design</li>
                            <li><i class="fas fa-check"></i> Wireframing</li>
                            <li><i class="fas fa-check"></i> Brand Identity</li>
                            <li><i class="fas fa-check"></i> Mobile Design</li>
                        </ul>
                        <div class="service-card-footer">
                            <a href="#contact" class="btn btn-secondary">Explore Design</a>
                        </div>
                    </div>
                </div>

                <div class="service-card content-edit-card">
                    <div class="service-card-header">
                        <div class="service-icon">
                            <i class="fas fa-edit"></i>
                        </div>
                        <h3>Content Editing</h3>
                    </div>
                    <div class="service-card-content">
                        <div class="service-price">
                            <span class="price-label">Starting at</span>
                            <span class="price-value">$49</span>
                        </div>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> Content Writing</li>
                            <li><i class="fas fa-check"></i> Proofreading</li>
                            <li><i class="fas fa-check"></i> Editing Services</li>
                            <li><i class="fas fa-check"></i> SEO Content</li>
                        </ul>
                        <div class="service-card-footer">
                            <a href="#contact" class="btn btn-tertiary">Edit Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    const navLinks = document.querySelector('.nav-links');
    const servicesNavItem = document.createElement('li');
    servicesNavItem.setAttribute('data-section', 'services');
    servicesNavItem.innerHTML = `
        <i class="fas fa-briefcase"></i>
        <span>Services</span>
    `;

    const main = document.querySelector('main');
    main.insertBefore(servicesSection, main.lastElementChild);
    navLinks.insertBefore(servicesNavItem, navLinks.lastElementChild);

    servicesNavItem.addEventListener('click', (e) => {
        document.querySelectorAll('.nav-links li').forEach(link => link.classList.remove('active'));
        
        e.currentTarget.classList.add('active');

        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
        servicesSection.classList.add('active');
        const sidebar = document.querySelector('.sidebar');
        if (sidebar.classList.contains('mobile-menu-open')) {
            sidebar.classList.remove('mobile-menu-open');
            document.querySelector('.mobile-menu-toggle')?.classList.remove('active');
        }
    });
});